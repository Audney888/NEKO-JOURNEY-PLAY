import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Input} from '../src/input.js';
import {SaveStore,defaultState,validateEnvelope,DEFAULT_SETTINGS} from '../src/store.js';
import {WORLD,CHARACTERS} from '../src/data.js';
function mem(){const data=new Map();return {getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)}}
test('seven playable cats, Kuro excluded; adult and kitten metadata remains correct',()=>{
 assert.deepEqual(CHARACTERS.map(x=>x.id),['bobo','doufu','buka','hongzao','coco','xiaokui','bimo']);
 assert.deepEqual(CHARACTERS.filter(x=>x.age_group==='adult').map(x=>x.id),['bobo','buka','bimo']);
});
test('World1_1 matches Godot graybox placement',()=>{
 assert.equal(WORLD.start.x,70);assert.equal(WORLD.goal.x,1500);assert.equal(WORLD.solids[0].w,900);
 assert.equal(WORLD.oneWays[0].x,850);assert.equal(WORLD.merchant.x,735);
});
test('new game/save/continue restores coins and inventory',()=>{
 const storage=mem(),a=new SaveStore(storage);a.newGame();a.changeCoins(8);
 assert.equal(a.purchase('healing_snack'),true);assert.equal(a.state.coins,3);
 const b=new SaveStore(storage);assert.equal(b.load(),true);assert.equal(b.state.inventory.healing_snack,1);
 assert.equal(b.state.coins,3);assert.equal(validateEnvelope(b.read()),true);
});
test('quest reward granted once and coin nodes cannot respawn exploit',()=>{
 const s=new SaveStore(mem());s.newGame();s.startQuest();
 assert.equal(s.collectCoin('Coin1'),true);assert.equal(s.collectCoin('Coin1'),false);
 s.collectCoin('Coin2');s.collectCoin('Coin3');
 assert.equal(s.state.coins,5);assert.equal(s.state.quests.tutorial_coins.state,'completed');
 s.collectCoin('Coin4');assert.equal(s.state.coins,6);
});
test('healing item only consumed while injured',()=>{
 const s=new SaveStore(mem());s.newGame();s.addItem('healing_snack',1);
 assert.equal(s.useItem('healing_snack',3,3),null);assert.equal(s.state.inventory.healing_snack,1);
 assert.equal(s.useItem('healing_snack',2,3),3);assert.equal(s.state.inventory.healing_snack,0);
});
test('malformed save and invalid inventory keys rejected',()=>{
 const s=defaultState();s.inventory.mystery=1;
 assert.equal(validateEnvelope({save_version:1,state:s,settings:{...DEFAULT_SETTINGS}}),false);
});
test('touch supports two held actions without unintended key stickiness',()=>{
 const input=new Input();input.press('right','pointer',1);input.press('jump','pointer',2);
 assert.equal(input.get('right'),true);assert.equal(input.tap('jump'),true);
 input.release('jump','pointer',2);assert.equal(input.get('right'),true);
 input.release('right','pointer',1);assert.equal(input.get('right'),false);
});
test('touch autorun starts after hold and resets on release',()=>{
 const i=new Input();i.press('right','pointer',1);i.step(.6);assert.equal(i.get('run'),true);
 i.release('right','pointer',1);assert.equal(i.get('run'),false);
});

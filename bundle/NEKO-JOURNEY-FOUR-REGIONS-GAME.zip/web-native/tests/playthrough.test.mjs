import {test} from 'node:test';
import assert from 'node:assert/strict';
import {NekoGame} from '../src/game.js';
import {SaveStore} from '../src/store.js';
import {LEVELS} from '../src/data.js';
const storage=()=>{const s=new Map();return {getItem:k=>s.get(k)??null,setItem:(k,v)=>s.set(k,v)}};
function fake(){
 const g=Object.create(NekoGame.prototype);
 g.store=new SaveStore(storage());g.store.newGame();
 g.input={flush(){},get(){return false},tap(){return false},step(){}};
 g.menu={hidden:false};g.menuInner={innerHTML:''};g.hud={hidden:false};g.touch={hidden:false};
 g.pauses=new Set();g.clock=0;g.levelIndex=0;g.camera=0;g.kuro={x:0,y:0};g.audio=()=>{};
 g.flash=()=>{};g.hint=()=>{};g.checkOrientation=()=>{};g.updateHud=()=>{};g.bindActions=()=>{};
 g.isTouch=()=>false;
 return g;
}
test('full four-region campaign progression and final result',()=>{
 const g=fake();
 for(const [index,level] of LEVELS.entries()){
  g.enterLevel();
  assert.equal(g.scene,'game');assert.equal(g.levelIndex,index);
  assert.ok(g.enemies.length>=3);
  if(index===3){
   assert.ok(g.enemies.some(e=>e.boss&&e.hp===3));
   g.bossDefeated=true;
  }
  g.player.x=g.world.goal.x;g.player.y=190;
  g.complete();
  assert.equal(g.scene,'result');
  if(index<3)assert.ok(g.store.state.unlocked_levels.includes(LEVELS[index+1].id));
 }
 assert.equal(g.store.state.unlocked_levels.length,4);
 assert.match(g.menuInner.innerHTML,/四季之旅/);
});
test('enemy hitboxes accept three strikes on Hokkaido boss',()=>{
 const g=fake();g.store.unlockLevel('world_4_1');g.enterLevel();
 const e=g.enemies.find(e=>e.boss);
 g.player.x=e.x-20;g.player.y=e.y-7;g.player.face=1;
 for(let i=0;i<3;i++){
  g.player.attackTime=0;e.hitCooldown=0;
  g.attack();
 }
 assert.equal(e.alive,false);assert.equal(g.bossDefeated,true);
});
test('player physics and collision update without DOM',()=>{
 const g=fake();g.enterLevel();let start=g.player.x;
 g.input.get=a=>a==='right';
 for(let i=0;i<20;i++)g.updatePlayer(1/60);
 assert.ok(g.player.x>start+10);
 assert.ok(g.player.y<=230);
});

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {NekoGame} from '../src/game.js';
import {CHARACTERS} from '../src/data.js';
import {SaveStore} from '../src/store.js';
const storage=()=>{const map=new Map();return {getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,v)}};
function fake(id){
 const g=Object.create(NekoGame.prototype);g.store=new SaveStore(storage());g.store.newGame();
 g.store.state.selected_character=id;g.store.save();g.input={flush(){},get(){return false},tap(){return false}};
 g.hud={hidden:true};g.menu={hidden:true};g.menuInner={innerHTML:''};g.touch={hidden:true};g.pauses=new Set();
 g.clock=0;g.levelIndex=0;g.camera=0;g.viewportWidth=480;g.kuro={x:0,y:0};
 g.isTouch=()=>false;g.audio=()=>{};g.flash=()=>{};g.hint=()=>{};g.checkOrientation=()=>{};g.updateHud=()=>{};
 g.enterLevel();return g;
}
test('seven character identities have seven different working skill dispatches',()=>{
 const abilities=new Set();
 for(const c of CHARACTERS){const g=fake(c.id),p=g.player;p.grounded=true;
  if(c.id==='doufu'){p.grounded=false;p.secondJump=1;}
  if(c.id==='hongzao')p.hp=2;
  g.skill();abilities.add(c.ability_id);
  assert.ok(p.skillCooldown>0,c.name+' ability must activate');
  if(c.id==='doufu')assert.equal(p.secondJump,0);
  if(c.id==='hongzao')assert.equal(p.hp,3);
  if(c.id==='bimo')assert.ok(p.invuln>=3);
  if(c.id==='bobo')assert.ok(p.dash>0);
 }
 assert.equal(abilities.size,7);
});
test('old Bobo-only save remains valid but unlocks newly implemented roster',()=>{
 const st=new SaveStore(storage());st.newGame();st.state.unlocked_characters=['bobo'];st.save();
 const reload=new SaveStore(st.storage);assert.equal(reload.load(),true);
 assert.equal(reload.state.unlocked_characters.length,7);
});

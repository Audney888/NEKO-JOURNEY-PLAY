import {spawn} from 'node:child_process';
import {setTimeout as sleep} from 'node:timers/promises';
import assert from 'node:assert/strict';
import {chromium} from 'playwright-core';
const server=spawn('python3',['-m','http.server','4181','--bind','127.0.0.1','--directory','dist'],{stdio:'ignore'});
let browser;
try{
 let ready=false;for(let i=0;i<50;i++){try{if((await fetch('http://127.0.0.1:4181/')).ok){ready=true;break}}catch{}await sleep(200)}
 assert.ok(ready,'Local static server failed');
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_BIN||'/usr/bin/google-chrome',args:['--no-sandbox']});
 for(const mobile of [false,true]){
  const context=await browser.newContext({viewport:mobile?{width:844,height:390}:{width:1280,height:720},hasTouch:mobile,isMobile:mobile});
  const page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:4181/?debug',{waitUntil:'networkidle'});
  await page.getByRole('button',{name:'開始旅程'}).click();
  await page.locator('[data-character="bobo"]').click();
  await page.locator('[data-menu-action="world_1_1"]').click();
  await page.waitForTimeout(400);
  assert.equal(await page.evaluate(()=>window.__NEKO_DEBUG__.scene),'game');
  assert.equal((await page.evaluate(()=>window.__NEKO_DEBUG__.x))>=0,true);
  assert.ok(await page.evaluate(()=>fetch('./assets/cats.png').then(r=>r.ok)),'Cat sprite atlas missing');
  assert.ok(await page.evaluate(()=>fetch('./assets/bg_3.png').then(r=>r.ok)),'Hokkaido background missing');
  if(mobile){assert.ok(await page.locator('#touch-controls').isVisible(),'Touch buttons hidden in landscape')}
  else {
   const x=await page.evaluate(()=>window.__NEKO_DEBUG__.x);
   await page.keyboard.down('ArrowRight');await page.waitForTimeout(360);await page.keyboard.up('ArrowRight');
   assert.ok(await page.evaluate(v=>window.__NEKO_DEBUG__.x>v,x),'Player did not move');
  }
  assert.deepEqual(errors,[],'Uncaught browser errors');
  console.log((mobile?'MOBILE':'DESKTOP')+' CHROMIUM SMOKE PASS');
  await context.close();
 }
}finally{await browser?.close();server.kill('SIGTERM')}

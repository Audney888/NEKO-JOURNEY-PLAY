import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const html=readFileSync(new URL('../index.html', import.meta.url),'utf8');
test('all player-facing touch buttons use traditional Chinese',()=>{
 for(const t of ['道具','對話','攻擊','技能','跳躍'])assert.match(html,new RegExp('>'+t+'</button>'));
 for(const english of ['>ITEM</button>','>TALK</button>','>ATK</button>','>SKILL</button>','>JUMP</button>'])assert.ok(!html.includes(english));
});

import {test} from 'node:test';
import assert from 'node:assert/strict';
import {LEVELS,WORLDS,REGION_PALETTES,CHARACTERS} from '../src/data.js';
import {SaveStore} from '../src/store.js';
const storage=()=>{const m=new Map();return {getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v)}};
test('four chapters contain reachable structure and a clear finish line',()=>{
 assert.equal(LEVELS.length,4);assert.equal(WORLDS.length,4);assert.equal(REGION_PALETTES.length,4);
 for(const [i,w] of WORLDS.entries()){
  assert.ok(w.solids.some(p=>p.x<=w.start.x&&p.y>=w.start.y+19));
  assert.ok(w.goal.x>1900&&w.goal.x<2280);
  assert.ok(w.enemies.length>=3,`stage ${i} enemy count`);
  assert.ok(w.coins.length>=8,`stage ${i} coin count`);
  assert.ok(w.checkpoint.x>800);
 }
 assert.equal(WORLDS[3].enemies.filter(e=>e.boss).length,1);
 assert.ok(WORLDS[3].enemies.find(e=>e.boss).hp>=3);
});
test('winning a chapter unlocks the next without overwriting coins/inventory',()=>{
 const st=new SaveStore(storage());st.newGame();st.changeCoins(6);st.addItem('healing_snack');
 for(const lvl of LEVELS.slice(1))assert.equal(st.unlockLevel(lvl.id),true);
 assert.equal(st.state.current_level,LEVELS[3].id);
 assert.equal(st.state.coins,6);assert.equal(st.state.inventory.healing_snack,1);
 assert.equal(st.state.unlocked_levels.length,4);
 const reload=new SaveStore(st.storage);assert.equal(reload.load(),true);
 assert.equal(reload.state.current_level,'world_4_1');
});
test('cat identities remain unchanged and only Bobo is playable',()=>{
 assert.deepEqual(CHARACTERS.map(c=>c.id),['bobo','doufu','buka','hongzao','coco','xiaokui','bimo']);
 assert.deepEqual(CHARACTERS.filter(c=>c.unlocked).map(c=>c.id),['bobo']);
});

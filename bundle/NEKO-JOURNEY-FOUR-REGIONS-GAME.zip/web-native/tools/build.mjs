import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dist=path.join(root,'dist');
fs.rmSync(dist,{recursive:true,force:true});fs.mkdirSync(dist,{recursive:true});
for(const name of ['index.html','style.css'])fs.copyFileSync(path.join(root,name),path.join(dist,name));
fs.cpSync(path.join(root,'src'),path.join(dist,'src'),{recursive:true});
fs.cpSync(path.join(root,'assets'),path.join(dist,'assets'),{recursive:true});
fs.writeFileSync(path.join(dist,'.nojekyll'),'');
for(const required of ['index.html','src/main.js','src/game.js','src/data.js','src/input.js','src/store.js']){
 if(!fs.existsSync(path.join(dist,required)))throw new Error(`Missing dist asset: ${required}`);
}
console.log('Web Native build ready:',dist);

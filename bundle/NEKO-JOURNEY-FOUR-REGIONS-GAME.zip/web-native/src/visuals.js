import {REGION_PALETTES} from './data.js';
const sources={cats:'assets/cats.png',items:'assets/items.png',...Object.fromEntries([0,1,2,3].map(i=>['bg'+i,`assets/bg_${i}.png`]))};
export const ART={images:new Map(),preload(){for(const [key,url] of Object.entries(sources)){const image=new Image();this.images.set(key,image);image.src=url}},get(key){const img=this.images.get(key);return img?.complete&&img.naturalWidth?img:null}};
function scenery(ctx,index,cam,viewWidth=480){const img=ART.get('bg'+index);if(!img)return false;const offset=Math.floor(cam*.26)%960;
 for(let x=-offset;x<viewWidth;x+=960)ctx.drawImage(img,x,0);return true}
export function drawWorld(ctx,index,cam,clock,viewWidth=480){
 ctx.fillStyle=['#93bfd1','#c4bfc8','#b0ddd1','#809fba'][index]||'#a9c5c3';ctx.fillRect(0,0,viewWidth,270);
 scenery(ctx,index,cam,viewWidth);
 // Gentle atmospheric perspective separates distant architecture from readable gameplay.
 ctx.fillStyle=['#cee4e137','#dad1e03b','#d6eedc39','#c9dce33b'][index];
 ctx.fillRect(0,56,viewWidth,168);
 if(index===3){ // gentle snow particles, anchored to camera & time
  ctx.fillStyle='#f5f3e6';for(let i=0;i<45;i++){const x=(i*81+Math.floor(clock*13))%viewWidth,y=(i*47+Math.floor(clock*8))%225;ctx.fillRect(x,y,i%3===0?2:1,2)}}
 if(index===2){ctx.fillStyle='#fce7de';for(let i=0;i<25;i++){const x=(i*67+Math.floor(clock*8))%viewWidth,y=(i*37+Math.floor(clock*5))%223;ctx.fillRect(x,y,2,2)}}
}
export function drawPlatform(ctx,b,index,thin=false){const p=REGION_PALETTES[index],step=16;
 ctx.fillStyle=p.ground;ctx.fillRect(b.x,b.y,b.w,b.h);
 ctx.fillStyle=p.top;ctx.fillRect(b.x,b.y,b.w,thin?3:5);
 ctx.fillStyle=p.rock;
 for(let y=b.y+10;y<b.y+b.h;y+=13)for(let x=b.x+((Math.floor(y/13)%2)*8);x<b.x+b.w;x+=step)ctx.fillRect(x+3,y,10,1);
 if(index===3){ctx.fillStyle='#e4ece8';for(let x=b.x;x<b.x+b.w;x+=16)ctx.fillRect(x,b.y,x%4?13:10,3)}
 else {ctx.fillStyle='#527962';for(let x=b.x;x<b.x+b.w;x+=23)ctx.fillRect(x,b.y-2,3,3)}
}
export function drawCat(ctx,row,x,y,frame=0,face=1,scale=1){const img=ART.get('cats');if(!img)return;ctx.save();const size=Math.round(32*scale);const yy=Math.round(y)-(size-32);if(face<0){ctx.translate(Math.round(x)+size,yy);ctx.scale(-1,1);ctx.drawImage(img,frame*32,row*32,32,32,0,0,size,size)}else ctx.drawImage(img,frame*32,row*32,32,32,Math.round(x),yy,size,size);ctx.restore();}
export function drawObject(ctx,col,x,y,scale=1){const img=ART.get('items');if(!img)return;ctx.drawImage(img,col*32,0,32,32,Math.round(x),Math.round(y),Math.round(32*scale),Math.round(32*scale))}

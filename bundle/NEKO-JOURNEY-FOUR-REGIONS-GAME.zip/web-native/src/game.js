import {VIEW,WORLD,ITEMS,QUEST,CHARACTERS,FUTURE_REGIONS,LEVELS,WORLDS,REGION_PALETTES} from './data.js';
import {Input} from './input.js';
import {SaveStore,DEFAULT_SETTINGS} from './store.js';
import {ART,drawWorld,drawPlatform,drawCat,drawObject} from './visuals.js';

const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
const overlap=(a,b)=>a.x < b.x+b.w&&a.x+a.w>b.x&&a.y < b.y+b.h&&a.y+a.h>b.y;
const rect=(x,y,w,h)=>({x,y,w,h});

export class NekoGame{
 constructor({canvas,menu,menuInner,hud,touch,rotate,toast}){
  Object.assign(this,{canvas,menu,menuInner,hud,touch,rotate,toast});
  this.ctx=canvas.getContext('2d',{alpha:false});this.ctx.imageSmoothingEnabled=false;
  this.store=new SaveStore();this.input=new Input();this.input.bindKeyboard();this.input.bindTouch(touch);
  this.scene='title';this.overlay=null;this.camera=0;this.player=null;this.enemies=[];this.kuro={x:35,y:160};this.levelIndex=0;this.world=WORLDS[0];this.bossDefeated=false;
  this.last=0;this.acc=0;this.clock=0;this.ticks=0;this.toastTimeout=0;this.interactObject=null;
  this.pauses=new Set();this.fatal=null;this.nextMelody=0;this.melodyPos=0;
  document.querySelector('#pause-fab').addEventListener('click',()=>this.pause());
  window.addEventListener('blur',()=>this.onFocusLost());
  document.addEventListener('visibilitychange',()=>{if(document.hidden)this.onFocusLost()});
  window.addEventListener('resize',()=>this.checkOrientation());
  window.addEventListener('orientationchange',()=>this.checkOrientation());
  window.visualViewport?.addEventListener('resize',()=>this.checkOrientation());
  document.addEventListener('contextmenu',e=>{if(e.target.closest('#stage'))e.preventDefault()});
  this.showTitle();this.checkOrientation();
  ART.preload();
 }
 run(){this.last=performance.now();requestAnimationFrame(t=>this.loop(t))}
 loop(ts){requestAnimationFrame(t=>this.loop(t));try{
  const dt=Math.min((ts-this.last)/1000,.1);this.last=ts;this.acc=Math.min(.2,this.acc+dt);
  while(this.acc>=1/60){this.step(1/60);this.acc-=1/60}
  this.draw();
  this.ticks++;
  if(this.ticks%8===0)this.updateHud();
 }catch(e){if(!this.fatal){this.fatal=e;console.error('NEKO runtime error:',e);this.flash('遊戲發生錯誤，請重新整理')}}}
 step(dt){this.clock+=dt;this.input.step(dt);if(this.scene==='game'&&!this.overlay&&!this.pauses.size)this.musicTick();
  if(this.scene!=='game')return;
  if(this.input.tap('pause')){if(this.overlay==='pause')this.closeOverlay();else if(!this.overlay)this.pause()}
  if(this.overlay||this.pauses.size||!this.player)return;
  if(this.input.tap('talk'))this.interact();
  if(this.input.tap('item'))this.useItem();
  if(this.input.tap('attack'))this.attack();
  if(this.input.tap('skill'))this.skill();
  this.updatePlayer(dt);this.updateEnemy(dt);this.updateKuro(dt);
  if(this.player.hp<=0||this.player.y>VIEW.height+100)this.respawn();
  if(Math.abs(this.player.x-this.world.goal.x)<18&&this.player.y>130&&(this.levelIndex!==3||this.bossDefeated))this.complete();
 }
 startFresh(){this.store.newGame();this.showCharacterSelect()}
 continueSaved(){if(!this.store.load()){this.flash('找不到有效存檔');this.showTitle();return}this.enterLevel(true)}
 enterLevel(fromSave=false){
  if(!this.store.state)this.store.newGame();
  const levelId=this.store.state.current_level;
  this.levelIndex=Math.max(0,LEVELS.findIndex(l=>l.id===levelId));
  this.world=WORLDS[this.levelIndex];const world=this.world;
  const cp=this.store.state.current_checkpoint;
  this.player={x:cp.id==='Checkpoint'?world.checkpoint.x:world.start.x,y:cp.id==='Checkpoint'?world.checkpoint.y-20:world.start.y,w:18,h:20,vx:0,vy:0,hp:3,maxHp:3,grounded:false,airDash:1,dash:0,dashCooldown:0,face:1,attackTime:0,invuln:0};
  this.enemies=world.enemies.map(e=>({...e,x:e.x-10,y:e.y,w:e.boss?29:20,h:e.boss?29:20,alive:true,originX:e.x-10,direction:-1,hitCooldown:0}));
  this.bossDefeated=false;this.nextMelody=0;this.melodyPos=0;this.camera=clamp(this.player.x-120,0,VIEW.worldWidth-VIEW.width);
  this.kuro={x:this.player.x-35,y:this.player.y-55};
  this.scene='game';this.overlay=null;this.pauses.clear();this.input.flush();this.menu.hidden=true;
  this.hud.hidden=false;this.touch.hidden=!this.isTouch();this.checkOrientation();this.updateHud();
  this.hint(fromSave?'已載入旅程進度':'跟著 Kuro 出發，收集金幣並前往終點。');
  this.audio('start');
 }
 isTouch(){return ('ontouchstart' in window)||navigator.maxTouchPoints>0||matchMedia('(pointer:coarse)').matches}
 checkOrientation(){const portrait=this.isTouch()&&innerHeight>innerWidth;this.rotate.hidden=!portrait;
   if(portrait&&this.scene==='game'){this.pauses.add('orientation');this.input.flush()}
   else this.pauses.delete('orientation');
   this.touch.hidden=this.scene!=='game'||!this.isTouch()||!!this.overlay||portrait;
 }
 onFocusLost(){this.input.flush();if(this.scene==='game'&&!this.overlay){this.pauses.add('focus');this.showPause(true)}}
 showScreen(html){this.scene='menu';this.menu.hidden=false;this.menuInner.innerHTML=html;this.hud.hidden=true;this.touch.hidden=true;this.input.flush();this.overlay=null;this.pauses.clear()}
 button(label,action,cls=''){return `<button type="button" class="btn ${cls}" data-menu-action="${action}">${label}</button>`}
 bindActions(map){for(const btn of this.menuInner.querySelectorAll('[data-menu-action]'))btn.addEventListener('click',()=>{map[btn.dataset.menuAction]?.()})}
 showTitle(){this.showScreen(`<div class="eyebrow">A SMALL ADVENTURE THROUGH JAPAN</div><div class="title-mark">✧ ねこ旅 ✧</div><h1>NEKO JOURNEY</h1><p>喵歷險記 · 四季之旅</p><div class="menu-actions">${this.button('開始旅程','new','main')}${this.button('繼續旅程','continue')}${this.button('音量設定','settings','ghost')}</div><p class="small">日本四地篇章 · 波波的冒險 · 觸控 / 鍵盤</p>`);
 const cont=this.menuInner.querySelector('[data-menu-action="continue"]');cont.disabled=!this.store.hasSave();
 this.bindActions({new:()=>this.startFresh(),continue:()=>this.continueSaved(),settings:()=>this.settings(()=>this.showTitle())});
 }
 showCharacterSelect(){this.showScreen(`<div class="eyebrow">01 · CHARACTER SELECT</div><h2>選擇夥伴</h2><div class="catgrid">${CHARACTERS.map(c=>`<button type="button" class="option" data-character="${c.id}" ${c.unlocked?'':'disabled'}>${c.name}<span>${c.unlocked?'可選擇':'未完成'}</span></button>`).join('')}</div><p class="small">波波：聰明、調皮的成年橘虎斑；Trick Dash 衝刺</p><div class="menu-actions">${this.button('返回主畫面','back','ghost')}</div>`);
 this.menuInner.querySelector('[data-character="bobo"]').addEventListener('click',()=>{this.store.state.selected_character='bobo';this.store.save();this.showLevelSelect()});this.bindActions({back:()=>this.showTitle()});}
 showLevelSelect(){this.showScreen(`<div class="eyebrow">02 · DESTINATIONS</div><h2>日本冒險地圖</h2><div class="level-list">${LEVELS.map((l,i)=>this.button(`${['壹','貳','參','肆'][i]}　${l.name} ${this.store.state.unlocked_levels.includes(l.id)?'↗':'🔒'}`,l.id,this.store.state.unlocked_levels.includes(l.id)?'main':'ghost')).join('')}</div><p class="small">依序完成四段旅程，保留進度可繼續冒險。</p>${this.button('返回角色選擇','back','ghost')}`);
 const actions={back:()=>this.showCharacterSelect()};
 for(const l of LEVELS) actions[l.id]=()=>{if(!this.store.state.unlocked_levels.includes(l.id))return;this.store.state.current_level=l.id;this.store.state.current_checkpoint={};this.store.save();this.enterLevel()};
 for(const btn of this.menuInner.querySelectorAll('[data-menu-action]'))if(btn.dataset.menuAction!=='back'&&!this.store.state.unlocked_levels.includes(btn.dataset.menuAction))btn.disabled=true;
 this.bindActions(actions);
 }
 pause(){if(this.scene!=='game'||this.overlay)return;this.pauses.add('manual');this.showPause(false)}
 showPause(focus=false){this.overlay='pause';this.input.flush();this.touch.hidden=true;this.menu.hidden=false;
 this.menuInner.innerHTML=`<div class="eyebrow">PAUSED</div><h2>暫停遊戲</h2><p>${focus?'離開分頁後已安全暫停':''}</p><div class="menu-actions">${this.button('繼續冒險','resume','main')}${this.button('重新開始關卡','restart')}${this.button('設定','settings')}${this.button('返回關卡選單','levels','ghost')}${this.button('返回主畫面','title','ghost')}</div>`;
 this.bindActions({resume:()=>this.closeOverlay(),restart:()=>{this.store.state.current_checkpoint={};this.store.save();this.enterLevel()},settings:()=>this.settings(()=>this.showPause()),levels:()=>this.showLevelSelect(),title:()=>this.showTitle()});}
 closeOverlay(){this.overlay=null;this.menu.hidden=true;this.pauses.clear();this.input.flush();this.checkOrientation()}
 settings(back){const previousScene=this.scene;this.overlay='settings';this.menu.hidden=false;this.touch.hidden=true;const s=this.store.settings;
 this.menuInner.innerHTML=`<div class="eyebrow">SETTINGS</div><h2>設定</h2>${[['master','主音量'],['music','音樂'],['sfx','音效'],['touch_opacity','觸控透明度']].map(([k,label])=>`<div class="setting"><label for="setting-${k}">${label}</label><input id="setting-${k}" data-setting="${k}" type="range" min="${k==='touch_opacity'?.2:0}" max="1" step="0.05" value="${s[k]}"></div>`).join('')}<p class="small">音訊播放架構預留；目前沒有正式音樂素材。</p>${this.button('返回','back','main')}`;
 for(const el of this.menuInner.querySelectorAll('[data-setting]'))el.addEventListener('input',()=>{this.store.updateSettings(el.dataset.setting,Number(el.value));this.touch.style.opacity=this.store.settings.touch_opacity});
 this.bindActions({back:()=>{if(previousScene==='game'){this.scene='game';back()}else back()}});
 }
 modal(type,title,body,buttons){this.overlay=type;this.input.flush();this.touch.hidden=true;this.menu.hidden=false;this.menuInner.innerHTML=`<div class="eyebrow">${type.toUpperCase()}</div><h2>${title}</h2><p>${body}</p><div class="menu-actions">${buttons.map(([label,id,cls])=>this.button(label,id,cls||'')).join('')}</div>`;this.bindActions(Object.fromEntries(buttons.map(([,id,,cb])=>[id,cb])))}
 interact(){const p=this.player,w=this.world;let near=[];if(Math.abs(p.x-w.npc.x)<55)near.push(['npc',Math.abs(p.x-w.npc.x)]);if(Math.abs(p.x-w.merchant.x)<55)near.push(['merchant',Math.abs(p.x-w.merchant.x)]);if(!near.length){this.hint('附近沒有可以互動的對象');return}near.sort((a,b)=>a[1]-b[1]);if(near[0][0]==='npc'){this.showDialogue()}else this.showShop()}
 showDialogue(){const first=this.store.startQuest();const intro=['歡迎來到東京・貓町！','大阪街燈的光芒正等著你。','九州的春風很溫柔，注意腳下的道路。','北方下雪了！要小心最後的守衛。'];const lines=[intro[this.levelIndex],first?'幫忙收集三枚金幣吧！完成後會得到 2 枚獎勵金幣。':'聽說每個地區都有自己的驚喜。保持好奇心！'];let idx=0;
 const render=()=>this.modal('dialogue','旅人貓',lines[idx],[[idx===lines.length-1?'結束對話':'下一頁','next','main',()=>{if(++idx>=lines.length)this.closeOverlay();else render()}]]);render();this.audio('talk')}
 showShop(){const item=ITEMS.healing_snack;const render=()=>this.modal('shop','喵喵上菜囉！',`歡迎光臨！<br>${item.name}：${item.price} 金幣／恢復 ${item.heal_amount} HP<br>目前金幣：${this.store.state.coins}，持有：${this.store.state.inventory[item.id]||0}`,[[`購買 ${item.name}`,'buy','main',()=>{this.flash(this.store.purchase(item.id)?'購買成功！':'金幣不足或背包已滿');render()}],['離開商店','close','ghost',()=>this.closeOverlay()]]);render()}
 useItem(){const p=this.player;const hp=this.store.useItem('healing_snack',p.hp,p.maxHp);if(hp===null){this.flash('目前無法使用恢復道具');return}p.hp=hp;this.flash('使用 Healing Snack：恢復 1 HP')}
 attack(){const p=this.player;if(p.attackTime>0)return;p.attackTime=.24;const hit={x:p.face>0?p.x+p.w:p.x-31,y:p.y-3,w:32,h:25};this.audio('attack');
 for(const e of this.enemies){if(!e.alive||!overlap(hit,e)||e.hitCooldown>0)continue;e.hp--;e.hitCooldown=.65;e.direction=p.face;e.x+=p.face*9;if(e.hp<=0){e.alive=false;if(e.boss){this.bossDefeated=true;this.flash('守衛已退散！前往終點 ✦')}else this.flash('擊退了迷途的怪物！')}else this.flash('守衛還有力氣，再攻擊一次！')}
 }
 skill(){const p=this.player;if(p.dash>0||p.dashCooldown>0)return;if(!p.grounded&&!p.airDash)return;
 if(!p.grounded)p.airDash--;p.dash=.2;p.dashCooldown=.32;p.vx=p.face*310;p.vy=0;this.flash('Trick Dash！');this.audio('dash')}
 updatePlayer(dt){const p=this.player;const moving=Number(this.input.get('right'))-Number(this.input.get('left'));if(moving)p.face=moving;p.attackTime=Math.max(0,p.attackTime-dt);p.invuln=Math.max(0,p.invuln-dt);p.dashCooldown=Math.max(0,p.dashCooldown-dt);
 if(p.dash>0){p.dash=Math.max(0,p.dash-dt);p.vx=p.face*310;p.vy=0}
 else{const max=this.input.get('run')?165:111;p.vx=moving*max;p.vy=Math.min(440,p.vy+720*dt);
 if(this.input.tap('jump')&&p.grounded){p.vy=-345;p.grounded=false}}
 const fromBottom=p.y+p.h;
 p.x+=p.vx*dt;
 for(const solid of this.world.solids)if(overlap(p,solid)){if(p.vx>0)p.x=solid.x-p.w;else if(p.vx<0)p.x=solid.x+solid.w;p.vx=0;p.dash=0}
 p.x=clamp(p.x,0,VIEW.worldWidth-p.w);
 p.y+=p.vy*dt;p.grounded=false;
 for(const solid of this.world.solids){if(overlap(p,solid)){
   if(p.vy>=0&&fromBottom<=solid.y+6){p.y=solid.y-p.h;p.vy=0;p.grounded=true}
   else if(p.vy<0){p.y=solid.y+solid.h;p.vy=0}
 }}
 for(const plat of this.world.oneWays)if(p.vy>=0&&fromBottom<=plat.y+4&&p.y+p.h>=plat.y&&p.x+p.w>plat.x&&p.x<plat.x+plat.w){p.y=plat.y-p.h;p.vy=0;p.grounded=true}
 if(p.grounded)p.airDash=1;
 for(const coin of this.world.coins){if(overlap(p,{x:coin.x-6,y:coin.y-8,w:12,h:15})&&this.store.collectCoin(coin.id))this.flash('獲得 1 枚金幣！')}
 const haz=this.world.hazard;if(overlap(p,haz)&&p.invuln<=0){p.hp--;p.invuln=1; p.vy=-190;this.flash('小心陷阱！')}
 this.camera=clamp(this.camera+(clamp(p.x-150,0,VIEW.worldWidth-VIEW.width)-this.camera)*Math.min(1,dt*7),0,VIEW.worldWidth-VIEW.width);
 }
 updateEnemy(dt){for(const e of this.enemies){if(!e.alive)continue;e.hitCooldown=Math.max(0,e.hitCooldown-dt);e.x+=e.direction*(e.boss?24:18)*dt;if(Math.abs(e.x-e.originX)>(e.boss?64:29))e.direction*=-1;
  if(overlap(this.player,e)&&this.player.invuln<=0){this.player.hp--;this.player.invuln=1;this.player.vy=-190;this.flash('受到傷害！');this.audio('hurt')}
 }}
 updateKuro(dt){const targetX=this.player.x-31,targetY=this.player.y-30+Math.sin(this.clock*4)*4;this.kuro.x+=(targetX-this.kuro.x)*Math.min(1,dt*3);this.kuro.y+=(targetY-this.kuro.y)*Math.min(1,dt*3)}
 respawn(){const cp=this.store.state.current_checkpoint;const anchor=cp.id==='Checkpoint'?this.world.checkpoint:this.world.start;const p=this.player;p.x=anchor.x;p.y=anchor.y-20;p.vx=0;p.vy=0;p.hp=p.maxHp;p.invuln=1.1;p.dash=0;this.flash('已返回檢查點')}
 complete(){this.scene='result';this.input.flush();this.touch.hidden=true;this.hud.hidden=true;this.menu.hidden=false;this.audio('clear');
 const last=this.levelIndex===LEVELS.length-1;const next=LEVELS[this.levelIndex+1];
 if(next)this.store.unlockLevel(next.id);else this.store.save();
 this.menuInner.innerHTML=`<div class="eyebrow">TRAVEL MEMORIES</div><div class="result-stars">✦ ✦ ✦</div><h1>${last?'四季之旅 · 完成！':'旅程完成！'}</h1><p>${LEVELS[this.levelIndex].name}　${last?'波波踏遍了四季，旅程未完待續。':'新的地區已經解鎖，前往下一站！'}</p><p>旅途金幣：${this.store.state.coins}</p><div class="menu-actions">${this.button(last?'再次探索日本':'前往下一站','next','main')}${this.button('返回關卡選單','levels')}${this.button('返回主畫面','title','ghost')}</div>`;
 this.bindActions({next:()=>{if(last){this.store.state.current_level=LEVELS[0].id;this.store.state.current_checkpoint={};this.store.save()}this.enterLevel()},levels:()=>this.showLevelSelect(),title:()=>this.showTitle()})
 }
 flash(message){this.toast.textContent=message;this.toast.classList.add('show');clearTimeout(this.toastTimeout);this.toastTimeout=setTimeout(()=>this.toast.classList.remove('show'),1800)}
 hint(message){this.hud.querySelector('#hint-display').textContent=`KURO ✧ ${message}`}
 updateHud(){if(this.scene!=='game'||!this.player)return;
 this.hud.querySelector('#hp-display').textContent='♥ '.repeat(this.player.hp).trim()+' ♡ '.repeat(this.player.maxHp-this.player.hp);
 this.hud.querySelector('#coin-display').textContent=`◉ ${this.store.state.coins} · ITEM ${this.store.state.inventory.healing_snack||0}`;
 const quest=this.store.state.quests[QUEST.id];this.hud.querySelector('#quest-display').textContent=quest?.state==='active'?`${QUEST.title}：${quest.progress}/${QUEST.target_amount}`:quest?.state==='completed'?'任務完成 ✓':'';
 this.touch.style.opacity=String(this.store.settings.touch_opacity);
 const p=this.player;
 if(this.overlay)return;
 if(Math.abs(p.x-this.world.checkpoint.x)<20&&this.store.state.current_checkpoint.id!=='Checkpoint'){this.store.setCheckpoint('Checkpoint');this.flash('檢查點已啟動！')}
 if(Math.abs(p.x-this.world.npc.x)<38)this.hint('按 E / TALK 與教學貓對話');
 else if(Math.abs(p.x-this.world.merchant.x)<45)this.hint('按 E / TALK 開啟商店');
 else if(Math.abs(p.x-this.world.goal.x)<75)this.hint('抵達終點！');
 }
 draw(){const ctx=this.ctx;ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false;
 drawWorld(ctx,this.levelIndex,this.camera,this.clock);
 if(this.scene!=='game'&&this.scene!=='result')return;
 const w=this.world;ctx.save();ctx.translate(-Math.round(this.camera),0);
 for(const b of w.solids)drawPlatform(ctx,b,this.levelIndex);
 for(const b of w.oneWays)drawPlatform(ctx,b,this.levelIndex,true);
 const h=w.hazard;ctx.fillStyle='#473638';for(let x=h.x;x<h.x+h.w;x+=9){ctx.beginPath();ctx.moveTo(x,h.y+h.h);ctx.lineTo(x+4,h.y);ctx.lineTo(x+9,h.y+h.h);ctx.fill()}
 for(const coin of w.coins){if(this.store.state?.collected_coins.includes(coin.id))continue;drawObject(ctx,0,coin.x-16,coin.y-19+Math.sin(this.clock*5+coin.x)*2,1)}
 drawObject(ctx,4,w.checkpoint.x-16,w.checkpoint.y-25,1);
 drawObject(ctx,5,w.goal.x-16,w.goal.y-25,1);
 drawCat(ctx,1,w.npc.x-17,w.npc.y-29,0);drawCat(ctx,3,w.merchant.x-17,w.merchant.y-29,0);
 if(Math.abs(this.player.x-w.npc.x)<90)this.drawSign(w.npc.x,w.npc.y-31,'對話','#f6dfbb');
 if(Math.abs(this.player.x-w.merchant.x)<90)this.drawSign(w.merchant.x,w.merchant.y-31,'商店','#f6d39b');
 for(const e of this.enemies)if(e.alive){ctx.globalAlpha=e.hitCooldown>0&&Math.floor(this.clock*14)%2===0?.65:1;drawObject(ctx,e.boss?7:1,e.x-6,e.y-9,e.boss?1.3:1);ctx.globalAlpha=1}
 if(this.player){const p=this.player;ctx.globalAlpha=p.invuln>0&&Math.floor(this.clock*15)%2===0?.5:1;
  const anim=p.dash>0?5:!p.grounded?4:Math.abs(p.vx)>25?Math.floor(this.clock*9)%2?2:3:Math.floor(this.clock*2)%2;
  drawCat(ctx,0,p.x-7,p.y-8,anim,p.face);ctx.globalAlpha=1;
  if(p.attackTime>0){ctx.strokeStyle='#fff4c7';ctx.lineWidth=2;ctx.strokeRect(p.face>0?p.x+p.w:p.x-23,p.y+4,22,13)}
  drawObject(ctx,6,this.kuro.x-16,this.kuro.y-16+Math.sin(this.clock*5)*2,1);
 }
 ctx.restore();}
 drawSign(x,y,label,color){const ctx=this.ctx;ctx.fillStyle='#3a4f4c';ctx.fillRect(x-1,y-20,2,20);ctx.fillStyle=color;const w=label.length*9+12;ctx.fillRect(x-w/2,y-32,w,14);ctx.fillStyle='#354b4d';ctx.font='bold 10px sans-serif';ctx.fillText(label,x-w/2+6,y-22)}
 musicTick(){try{const ac=this.sound;if(!ac||ac.state!=='running'||this.store.settings.music<=0)return;
  if(this.nextMelody<ac.currentTime)this.nextMelody=ac.currentTime+.04;
  const scales=[[0,4,7,9,7,4,2,4],[0,3,7,10,7,5,3,5],[0,5,9,7,5,2,4,2],[0,3,5,7,10,7,5,3]];
  const root=[262,294,247,220][this.levelIndex];
  while(this.nextMelody<ac.currentTime+.16){const step=scales[this.levelIndex][this.melodyPos++%8],frequency=root*Math.pow(2,step/12),start=this.nextMelody;
   const o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.setValueAtTime(frequency,start);
   const vol=.017*this.store.settings.master*this.store.settings.music;
   g.gain.setValueAtTime(.0001,start);g.gain.linearRampToValueAtTime(vol,start+.045);g.gain.exponentialRampToValueAtTime(.0001,start+.32);
   o.connect(g).connect(ac.destination);o.start(start);o.stop(start+.34);this.nextMelody+=.37;
  }
 }catch{}}
 audio(kind){try{if(!this.sound){this.sound=new (window.AudioContext||window.webkitAudioContext)()}if(this.sound.state==='suspended')this.sound.resume();const ac=this.sound;
 const o=ac.createOscillator(),g=ac.createGain();o.type=kind==='hurt'?'sawtooth':'triangle';o.frequency.value=({start:440,talk:560,attack:240,dash:620,clear:700,hurt:150}[kind]||440);g.gain.setValueAtTime(.0001,ac.currentTime);g.gain.exponentialRampToValueAtTime(.05*this.store.settings.master*this.store.settings.sfx+.0001,ac.currentTime+.015);g.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+.14);o.connect(g).connect(ac.destination);o.start();o.stop(ac.currentTime+.15)}catch{}}
}

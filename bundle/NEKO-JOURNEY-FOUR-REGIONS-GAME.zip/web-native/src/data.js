// Explicit data ported from the existing Godot CharacterRegistry and World1_1 scene.
export const VIEW = Object.freeze({ width: 480, height: 270, worldWidth: 2280 });
export const CHARACTERS = Object.freeze([
  { id:'bobo', name:'波波', age_group:'adult', body_type:'standard', ability_id:'bobo_trick_dash', skill_name:'奇襲衝刺', unlocked:true, description:'聰明又調皮的橘虎斑冒險家' },
  { id:'doufu', name:'豆福', age_group:'kitten', body_type:'kitten', ability_id:'double_jump', skill_name:'二段跳躍', unlocked:true, description:'溫柔愛玩的麒麟尾小貓' },
  { id:'buka', name:'布卡', age_group:'adult', body_type:'round', ability_id:'royal_slide', skill_name:'優雅滑行', unlocked:true, description:'傲嬌的黑白貓公主' },
  { id:'hongzao', name:'紅棗', age_group:'kitten', body_type:'kitten', ability_id:'comfort_call', skill_name:'安撫呼喚', unlocked:true, description:'貼心又怕寂寞的小虎斑' },
  { id:'coco', name:'可可', age_group:'kitten', body_type:'kitten', ability_id:'curious_dash', skill_name:'探索衝刺', unlocked:true, description:'活潑好奇的黑色幼貓' },
  { id:'xiaokui', name:'小葵', age_group:'kitten', body_type:'slim', ability_id:'petal_wind', skill_name:'花瓣風', unlocked:true, description:'銀灰虎斑、短尾的優雅幼貓' },
  { id:'bimo', name:'畢莫', age_group:'adult', body_type:'standard', ability_id:'shadow_guard', skill_name:'暗影守護', unlocked:true, description:'害羞細膩的黑色成年貓' }
]);
export const LEVELS = Object.freeze([
 {id:'world_1_1',name:'東京・貓町',region:'Tokyo',unlocked:true},
 {id:'world_2_1',name:'大阪・燈火街',region:'Osaka',unlocked:false},
 {id:'world_3_1',name:'九州・花影之路',region:'Kyushu',unlocked:false},
 {id:'world_4_1',name:'北海道・雪夜車站',region:'Hokkaido',unlocked:false}
]);
export const FUTURE_REGIONS = Object.freeze(['大阪','九州','北海道']);
export const ITEMS = Object.freeze({healing_snack:{id:'healing_snack',name:'療癒點心',price:5,heal_amount:1,stack_limit:99}});
export const QUEST = Object.freeze({id:'tutorial_coins',title:'收集三枚金幣',target_amount:3,reward_coins:2});
export const WORLD = Object.freeze({
  start:{x:70,y:210}, goal:{x:1500,y:200}, checkpoint:{id:'Checkpoint',x:820,y:215},
  solids:[
    {x:0,y:230,w:900,h:40}, {x:1100,y:230,w:1180,h:40},
    {x:335,y:202,w:110,h:28}, {x:570,y:158,w:120,h:72},
    {x:1048,y:70,w:24,h:170}
  ],
  oneWays:[{x:850,y:149,w:100,h:12}],
  coins:[{id:'Coin1',x:260,y:205},{id:'Coin2',x:390,y:180},{id:'Coin3',x:630,y:140},{id:'Coin4',x:900,y:125},{id:'Coin5',x:1280,y:205}],
  npc:{id:'TutorialNPC',x:175,y:220}, merchant:{id:'MerchantNPC',x:735,y:220},
  enemy:{id:'Enemy',x:485,y:210}, hazard:{x:1152,y:218,w:36,h:12},
  deathPit:{x:900,y:270,w:200,h:400}, hiddenRoute:{x:850,y:149,w:100,h:12}
});

// Four self-contained, finishable Web adventure stages. Tokyo's original graybox positions
// remain authoritative. The other areas are new, clearly scoped Web chapters.
const stage=(i,segments,opts={})=>({
 start:{x:70,y:210},goal:{x:2080,y:200},checkpoint:{id:'Checkpoint',x:1100,y:205},
 solids:segments.map(([x,y,w,h])=>({x,y,w,h})),
 oneWays:[{x:430,y:178,w:95,h:10},{x:930,y:169,w:90,h:10},{x:1540,y:175,w:100,h:10}],
 coins:[220,395,478,750,960,1230,1490,1720,1990].map((x,n)=>({id:`world_${i+1}_1_Coin${n}`,x,y: n===2 ? 145 : n===4 ? 136:199})),
 npc:{id:'TutorialNPC',x:168,y:212},merchant:{id:'MerchantNPC',x:755,y:212},
 enemies:[{id:`e${i}_0`,x:555,y:210,hp:1},{id:`e${i}_1`,x:1350,y:210,hp:1},{id:`e${i}_2`,x:1840,y:210,hp:i===3?3:1,boss:i===3}],
 hazard:{x:1590,y:218,w:38,h:12},...opts,
});
export const WORLDS=Object.freeze([
 {...WORLD,goal:{x:2080,y:200},enemies:[{id:'tokyo_p0',x:485,y:210,hp:1},{id:'tokyo_p1',x:1380,y:210,hp:1},{id:'tokyo_p2',x:1890,y:210,hp:1}],
  coins:[...WORLD.coins,{id:'Coin6',x:1585,y:205},{id:'Coin7',x:1780,y:205},{id:'Coin8',x:2040,y:205}]},
 stage(1,[[0,230,650,40],[720,230,680,40],[1460,230,820,40],[370,197,95,33],[790,196,110,34],[1300,184,95,15]],{checkpoint:{id:'Checkpoint',x:1140,y:206},hazard:{x:1470,y:215,w:31,h:15}}),
 stage(2,[[0,230,760,40],[820,230,720,40],[1610,230,670,40],[320,201,110,29],[970,194,100,36],[1500,174,115,12]],{checkpoint:{id:'Checkpoint',x:1240,y:207},hazard:{x:1680,y:218,w:38,h:12}}),
 stage(3,[[0,230,840,40],[900,230,610,40],[1570,230,710,40],[380,192,115,38],[970,191,112,39],[1440,179,100,14]],{checkpoint:{id:'Checkpoint',x:1160,y:207},hazard:{x:1620,y:216,w:45,h:14}})
]);
export const REGION_PALETTES=Object.freeze([
 {ground:'#465e54',top:'#9db77e',rock:'#7b8e75',accent:'#e4bd75'},
 {ground:'#5c5360',top:'#c9b18d',rock:'#988c96',accent:'#e4b977'},
 {ground:'#46675c',top:'#a7caa0',rock:'#829d8c',accent:'#f2d39b'},
 {ground:'#52657c',top:'#d8e5e5',rock:'#95a5b7',accent:'#c7e8f4'}
]);

from PIL import Image, ImageDraw
from pathlib import Path
import math, random
P=Path('/mnt/data/neko_work/web-native/assets');P.mkdir(parents=True,exist_ok=True)
W,H=960,270
PALETTES=[
 {'sky1':'#83c6df','sky2':'#f5daba','haze':'#eddcc3','far':'#9babb2','far2':'#bbc4be','plaster':'#eadcbe','wood':'#674c47','roof':'#4b6574','roof2':'#78939c','plant':'#507a61','plant2':'#94ab76','glow':'#ffc877','main':'#cb736b','stone':'#767c70'},
 {'sky1':'#a7bcd0','sky2':'#f9d9b5','haze':'#f2d8be','far':'#adaab1','far2':'#d3c0b1','plaster':'#f1d3ac','wood':'#74504a','roof':'#65616f','roof2':'#9b8090','plant':'#658665','plant2':'#a7b66e','glow':'#ffce86','main':'#c56b56','stone':'#837777'},
 {'sky1':'#8ed4d8','sky2':'#e2eac6','haze':'#d4dcc4','far':'#95bbb4','far2':'#b0c7b2','plaster':'#ddd4ae','wood':'#746b56','roof':'#56776c','roof2':'#8b9d7f','plant':'#4d9079','plant2':'#9fc783','glow':'#ffe4a3','main':'#c48167','stone':'#8a9183'},
 {'sky1':'#668fb1','sky2':'#d4deec','haze':'#b8c9d8','far':'#859ab4','far2':'#a6b3c5','plaster':'#e2dfd7','wood':'#5b6375','roof':'#546d89','roof2':'#809bb8','plant':'#557a80','plant2':'#91afad','glow':'#ffdd99','main':'#a66b69','stone':'#7b8795'},
]

def rr(d,xy,c,outline=None,width=1): d.rectangle(tuple(map(int,xy)),fill=c,outline=outline,width=width)
def poly(d,pts,c): d.polygon([(int(x),int(y)) for x,y in pts],fill=c)
def line(d,pts,c,w=1): d.line([(int(x),int(y)) for x,y in pts],fill=c,width=w)
def gradient(im,top,bottom):
 def rgb(c):return tuple(bytes.fromhex(c.lstrip('#')))
 a,b=rgb(top),rgb(bottom);d=ImageDraw.Draw(im)
 for y in range(H):
  t=y/H;c=tuple(round(a[k]*(1-t)+b[k]*t) for k in range(3));d.line((0,y,W,y),fill=c)
def clouds(d,x,y):
 for dx,dy,ww,hh in [(-25,5,67,9),(-9,-4,46,12),(5,-12,24,8),(44,4,31,7)]:rr(d,(x+dx,y+dy,x+dx+ww,y+dy+hh),'#f5eee0')
 for dx,dy,ww in [(-18,8,43),(-1,0,35),(9,-8,19)]:line(d,[(x+dx,y+dy),(x+dx+ww,y+dy)],'#fffaf0',2)
def hill(d,x,y,r,c):poly(d,[(x-r,y+66),(x-r*.85,y+23),(x-r*.5,y-8),(x-r*.2,y-25),(x,y-41),(x+r*.2,y-18),(x+r*.46,y-5),(x+r*.82,y+25),(x+r,y+66)],c)
def city(d,seed,p):
 rng=random.Random(seed)
 for i in range(-1,34):
  x=i*34+(i%4)*7; y=rng.randrange(122,179); w=rng.randint(24,41)
  c=p['far'] if i%3 else p['far2'];rr(d,(x,y,x+w,216),c)
  if i%6==0:rr(d,(x+w//2-1,y-17,x+w//2+1,y-1),c)
  for xx in range(x+7,x+w-4,9):
   for yy in range(y+9,210,12):rr(d,(xx,yy,xx+3,yy+4),'#e5ddd0' if i%4 else '#bdc7c4')

def mountains(d,p,level):
 for i in range(-2,8):
  x=i*210+35; c=p['far'] if i%2 else p['far2']
  if level in (2,3):
   hill(d,x,182,160,c)
   if level==3:poly(d,[(x-62,147),(x,101),(x+55,146),(x+24,138),(x,117),(x-16,133)],'#f3f5ef')
  else:hill(d,x,184,110,c)

def blossom(d,x,y,seed,pink=False):
 rng=random.Random(seed);trunk='#765b51';c='#dbb5af' if pink else '#537d69';light='#f4c5c2' if pink else '#8bb18a'
 rr(d,(x-3,y-42,x+4,y+24),trunk);line(d,[(x,y-25),(x-19,y-45)],trunk,4);line(d,[(x,y-31),(x+23,y-55)],trunk,3)
 for bx,by,sz in [(-20,-51,19),(6,-65,28),(29,-52,23),(-6,-73,18)]:
  cx=x+bx;cy=y+by;rr(d,(cx-sz//2,cy-sz//2,cx+sz//2,cy+sz//2),c)
  for _ in range(9):
   px=cx+rng.randrange(-sz//2,sz//2+1);py=cy+rng.randrange(-sz//2,sz//2+1)
   rr(d,(px,py,px+2,py+2),light)

def house(d,x,y,w,h,p,idx,level):
 """Architecturally legible layered storefront; 1px outlines and limited accents."""
 rng=random.Random(1100+level*100+idx)
 wall=p['plaster'];edge=p['wood']; roof=p['roof'];roof2=p['roof2'];base=y+h
 rr(d,(x,y,x+w,base),edge)
 rr(d,(x+3,y+4,x+w-3,base-3),wall)
 rr(d,(x+6,base-10,x+w-6,base-7),'#a68b73')
 for yy in range(y+7,base,25):line(d,[(x+3,yy),(x+w-3,yy)],'#b7ae9e')
 # decorated roof
 poly(d,[(x-8,y+3),(x+9,y-16),(x+w-9,y-16),(x+w+8,y+3)],roof)
 rr(d,(x-10,y+3,x+w+10,y+7),edge)
 for xx in range(x-4,x+w+4,12):
  line(d,[(xx,y-10),(xx+4,y-7)],roof2,2)
  rr(d,(xx,y-1,xx+2,y+1),roof2)
 # wooden shop window or residence screen
 for yy in (y+22,):
  rr(d,(x+9,yy,x+w-9,yy+34),'#4e5556',edge,2)
  rr(d,(x+11,yy+2,x+w-11,yy+31),'#789794')
  for xx in range(x+12,x+w-11,20):rr(d,(xx,yy+3,xx+2,yy+30),edge)
  rr(d,(x+11,yy+15,x+w-10,yy+17),edge)
  for xx in range(x+16,x+w-12,21):
   rr(d,(xx,yy+7,xx+9,yy+13),'#aab9ae')
  rr(d,(x+8,yy+33,x+w-8,yy+37),edge)
 if h>92:
  rr(d,(x+10,y+68,x+w-10,y+74),edge)
  for xx in range(x+18,x+w-17,17):rr(d,(xx,y+78,xx+11,y+89),'#ad9e84')
 # banners hang at side
 accent=p['main']
 if idx%2==0:
  rr(d,(x+w-27,y+13,x+w-9,y+32),'#efe0c7')
  rr(d,(x+w-26,y+13,x+w-10,y+15),accent)
  for k in range(3):rr(d,(x+w-22+k*5,y+19,x+w-21+k*5,y+25),accent)
 else:
  rr(d,(x+12,y+59,x+26,y+90),accent)
  for k in range(3):rr(d,(x+14+k*4,y+63,x+15+k*4,y+68),'#f9e0ad')
 # landmark-specific storefront identity and lived-in town details.
 if idx%4==0:
  # Traditional cloth noren over wooden sliding doors
  rr(d,(x+15,y+16,x+56,y+29),'#f0e7d7')
  for nx in range(17,54,12):
   rr(d,(x+nx,y+16,x+nx+9,y+28),'#e8dfca')
   rr(d,(x+nx+2,y+19,x+nx+5,y+22),p['main'])
  rr(d,(x+22,y+67,x+48,y+70),'#7f6f5a')
 elif idx%4==1:
  # balcony rail + rice-paper sliding doors
  rr(d,(x+15,y+15,x+w-15,y+18),p['wood'])
  for q in range(x+18,x+w-16,12):rr(d,(q,y+15,q+2,y+34),p['wood'])
  rr(d,(x+14,y+34,x+w-14,y+36),p['wood'])
 elif idx%4==2:
  # crisp vertical shop banner and paper lantern
  rr(d,(x+23,y+47,x+36,y+84),'#d2c5a8')
  rr(d,(x+23,y+49,x+36,y+51),p['main'])
  for j in range(4):rr(d,(x+29,y+55+j*6,x+30,y+58+j*6),p['wood'])
  rr(d,(x+w-23,y+9,x+w-12,y+27),p['glow'])
  rr(d,(x+w-24,y+8,x+w-11,y+10),p['wood'])
 else:
  # lower exterior woodwork and little hanging plants
  for q in range(x+11,x+w-8,13):rr(d,(q,y+65,q+9,y+67),p['wood'])
  rr(d,(x+w-35,y+73,x+w-22,y+78),'#c2a885')
  rr(d,(x+w-32,y+67,x+w-24,y+72),p['plant'])
 # small foliage
 rr(d,(x+w-8,base-14,x+w-1,base-8),p['plant'])
 for dx in (0,7,11):rr(d,(x+w-10+dx,base-24+dx%3,x+w-6+dx,base-16),p['plant2'])

def make_bg(level):
 p=PALETTES[level];rng=random.Random(904+level)
 im=Image.new('RGB',(W,H));gradient(im,p['sky1'],p['sky2']);d=ImageDraw.Draw(im)
 if level==3:
  for _ in range(70):
   x,y=rng.randrange(W),rng.randrange(5,115);rr(d,(x,y,x+1,y+1),'#e8f0eb')
 for x,y in [(115,39),(470,59),(826,34)]:clouds(d,x,y)
 mountains(d,p,level)
 if level==0:
  # Tokyo Skytree in the distance
  x=714;line(d,[(x,155),(x-5,60),(x-1,23),(x+1,23),(x+6,60),(x,155)],'#9ba3a7',2)
  for yy in (66,84,110):rr(d,(x-12,yy,x+12,yy+3),'#b9b1a8')
 if level==1:
  # Dotonbori-esque riverside skyline and bridge silhouettes
  rr(d,(0,185,W,205),'#acb7b8');rr(d,(0,195,W,211),'#879d9f')
  for x in (90,520):rr(d,(x,173,x+125,178),'#b9897a')
 if level==2:
  for x in (125,755):
   poly(d,[(x-35,190),(x-19,140),(x+7,103),(x+32,148),(x+64,190)],p['far'])
  for x in (200,590,864):blossom(d,x,193,seed=x,pink=True)
 if level==3:
  for x in (85,350,735):
   poly(d,[(x-27,208),(x,148),(x+32,208)],'#55767e');poly(d,[(x-21,186),(x,151),(x+18,185)],'#b5c8ca')
 city(d,level+50,p)
 # close, repeated neighborhoods
 for idx in range(8):
  x=idx*130-20
  w=rng.randint(91,126); h=rng.randint(88,108);y=220-h
  if level==3:y+=4
  house(d,x,y,w,h,p,idx,level)
  if idx in (1,4,7):blossom(d,x+w+11,211,seed=level*45+idx,pink=level in (1,2))
  if idx in (2,6):
   rr(d,(x+w+5,173,x+w+8,218),'#776b59')
   rr(d,(x+w-1,176,x+w+14,188),p['main'])
   rr(d,(x+w+1,177,x+w+12,183),p['glow'])
 # sidewalk and shadow
 rr(d,(0,218,W,228),p['stone']);rr(d,(0,217,W,218),'#d1c7a5')
 for x in range(0,W,20):rr(d,(x,225,x+14,226),'#a4a797')
 im.save(P/f'bg_{level}.png',optimize=True)

for i in range(4):make_bg(i)
print('generated backgrounds',[(p.name,p.stat().st_size) for p in P.glob('bg_*.png')])
# Consistent pixel sprite atlas: seven distinctly marked cats x six animation poses.
S=32
cats=[
 dict(name='bobo',coat='#d9924b',shadow='#ac6436',chest='#f1cb91',stripe='#9b603f',eyes='#78994d',type='orange',adult=True),
 dict(name='doufu',coat='#242a34',shadow='#191f28',chest='#fbf0de',stripe='#242a34',eyes='#7caa8d',type='tux',adult=False),
 dict(name='buka',coat='#292c33',shadow='#191d24',chest='#f4ead7',stripe='#343642',eyes='#c6ad68',type='tux',adult=True),
 dict(name='hongzao',coat='#c88960',shadow='#a76547',chest='#f4d1a5',stripe='#925637',eyes='#a5b66e',type='tabby',adult=False),
 dict(name='coco',coat='#292d34',shadow='#171e24',chest='#292d34',stripe='#292d34',eyes='#e5cb65',type='black',adult=False),
 dict(name='xiaokui',coat='#abb5b5',shadow='#6b858b',chest='#e2ded0',stripe='#788d96',eyes='#79b584',type='gray',adult=False),
 dict(name='bimo',coat='#313037',shadow='#1d2730',chest='#313037',stripe='#313037',eyes='#80c8b7',type='black',adult=True),
]
im=Image.new('RGBA',(S*6,S*7));d=ImageDraw.Draw(im)
for row,c in enumerate(cats):
 for f in range(6):
  ox=f*S;oy=row*S;ground=24;
  adult=c['adult'];headw=15 if adult else 14; bodyw=16 if adult else 13
  bob= -1 if f in (1,3) else (-3 if f==4 else 0)
  # running stride, leap f4, dash f5
  foot=ground+bob;bodyy=12+bob
  coat=c['coat'];shadow=c['shadow'];stripe=c['stripe']
  # curled tail silhouette
  tailx=ox+5+(2 if f==5 else 0)
  rr(d,(tailx-3,oy+bodyy+3,tailx+1,oy+bodyy+11),'#34413a' if row==0 else shadow)
  rr(d,(tailx-6,oy+bodyy,tailx-3,oy+bodyy+7),coat)
  rr(d,(tailx-7,oy+bodyy-3,tailx-4,oy+bodyy+2),coat)
  # body with dark outline
  rr(d,(ox+7,oy+bodyy-1,ox+26 if adult else ox+23,oy+foot),shadow)
  rr(d,(ox+8,oy+bodyy,ox+25 if adult else ox+22,oy+foot-2),coat)
  # hind leg and feet differentiated by animation pose
  step=3 if f==2 else (-3 if f==3 else 0)
  for dx in (10,21 if adult else 19):
   yy=foot-3 if f==4 else foot
   rr(d,(ox+dx+step*(1 if dx<15 else -1),oy+yy-3,ox+dx+3+step*(1 if dx<15 else -1),oy+yy+1),shadow)
   rr(d,(ox+dx+1+step*(1 if dx<15 else -1),oy+yy-2,ox+dx+3+step*(1 if dx<15 else -1),oy+yy),c['chest'] if row in (1,2,5) else coat)
  if c['type']=='tux':rr(d,(ox+20,oy+bodyy+2,ox+24,oy+foot-3),c['chest'])
  if c['type']=='tabby':
   for dx in (15,20):rr(d,(ox+dx,oy+bodyy+1,ox+dx+2,oy+bodyy+2),stripe)
  if row==0:
   # Bobo leaf-shaped satchel and scroll
   rr(d,(ox+12,oy+bodyy-4,ox+21,oy+bodyy+3),'#5b543e')
   rr(d,(ox+13,oy+bodyy-3,ox+20,oy+bodyy+2),'#956e45')
   rr(d,(ox+16,oy+bodyy-6,ox+18,oy+bodyy-3),'#e8ca8d')
   rr(d,(ox+14,oy+bodyy-4,ox+17,oy+bodyy-4),'#f2ddb7')
  # head and ears
  hx=ox+16; hy=oy+7+bob
  rr(d,(hx-7,hy-1,hx+7,hy+11),shadow)
  rr(d,(hx-6,hy,hx+6,hy+10),coat)
  poly(d,[(hx-7,hy+2),(hx-7,hy-5),(hx-1,hy+1)],shadow)
  poly(d,[(hx+7,hy+2),(hx+7,hy-5),(hx+1,hy+1)],shadow)
  poly(d,[(hx-6,hy),(hx-5,hy-3),(hx-2,hy+1)],'#d8a29b' if row not in (4,6) else '#735a64')
  poly(d,[(hx+6,hy),(hx+5,hy-3),(hx+2,hy+1)],'#d8a29b' if row not in (4,6) else '#735a64')
  if c['type'] in ('orange','tabby','gray'):
   rr(d,(hx-2,hy,hx+1,hy+3),stripe)
   rr(d,(hx-6,hy+4,hx-4,hy+4),stripe)
   rr(d,(hx+4,hy+4,hx+6,hy+4),stripe)
  if c['type']=='tux':
   rr(d,(hx-3,hy+6,hx+3,hy+10),c['chest'])
   if row==2:rr(d,(hx-3,hy-2,hx+1,hy+2),c['chest'])
   else:rr(d,(hx-1,hy+10,hx,hy+11),'#1b2228')
  # small muzzle
  if c['type']!='black':rr(d,(hx-3,hy+7,hx+3,hy+10),c['chest'])
  eye_y=hy+5
  rr(d,(hx-4,eye_y,hx-3,eye_y+1),c['eyes'])
  rr(d,(hx+3,eye_y,hx+4,eye_y+1),c['eyes'])
  rr(d,(hx-3,eye_y+1,hx-3,eye_y+1),'#1c2731')
  rr(d,(hx+4,eye_y+1,hx+4,eye_y+1),'#1c2731')
  rr(d,(hx,hy+8,hx+1,hy+8),'#734c4b')
  if row==0:
   rr(d,(hx-5,hy+10,hx+5,hy+11),'#518565');rr(d,(hx+1,hy+11,hx+2,hy+12),'#e3c06e')
  if row==5:rr(d,(ox+24,oy+bodyy+5,ox+26,oy+bodyy+7),'#667e88') # short tail
  if f==5:
   for xx,ww in ((2,4),(6,3)):rr(d,(ox+xx,oy+16,ox+xx+ww,oy+17),'#e9e2b7')
im.save(P/'cats.png',optimize=True)

# Collectibles, enemies and foreground tiles use transparent sprites; all are imported game assets.
im2=Image.new('RGBA',(32*8,32));t=ImageDraw.Draw(im2)
for k in range(8):
 ox=k*32
 if k==0: # coin
  rr(t,(ox+10,8,ox+21,23),'#805b35');rr(t,(ox+11,7,ox+20,22),'#f8df8d')
  rr(t,(ox+13,9,ox+18,20),'#dca94d');rr(t,(ox+15,12,ox+16,18),'#fff4bc')
 if k==1: # ghosty enemy with eyes, shadow
  rr(t,(ox+7,10,ox+25,24),'#46515c');rr(t,(ox+9,7,ox+23,12),'#72818a')
  for x in (11,20):rr(t,(ox+x,16,ox+x+3,19),'#f0d2a1')
  for x in (12,20):rr(t,(ox+x,17,ox+x,17),'#272c34')
  for x in (8,17,23):rr(t,(ox+x,23,ox+x+3,27),'#46515c')
 if k==2: # merchant meal
  rr(t,(ox+7,18,ox+25,23),'#dfbd8c');rr(t,(ox+10,13,ox+22,18),'#d9795a')
  rr(t,(ox+12,9,ox+20,13),'#f1d8a4')
 if k==3: # lantern
  rr(t,(ox+12,5,ox+20,8),'#61545b');rr(t,(ox+10,9,ox+22,22),'#b96867');rr(t,(ox+12,11,ox+20,20),'#f6ba7a');rr(t,(ox+12,23,ox+20,25),'#61545b')
 if k==4: # checkpoint
  rr(t,(ox+15,9,ox+17,29),'#4d5358');poly(t,[(ox+17,8),(ox+27,12),(ox+17,19)],'#76aa85')
 if k==5: # star
  poly(t,[(ox+16,5),(ox+20,12),(ox+28,15),(ox+20,18),(ox+16,27),(ox+12,18),(ox+4,15),(ox+12,12)],'#f3de91')
 if k==6: # Kuro angel companion
  rr(t,(ox+11,10,ox+22,23),'#202934');poly(t,[(ox+11,14),(ox+10,6),(ox+15,11)],'#202934');poly(t,[(ox+21,12),(ox+23,6),(ox+18,11)],'#202934')
  poly(t,[(ox+11,18),(ox+3,15),(ox+7,23)],'#d5e2dc');poly(t,[(ox+22,18),(ox+30,15),(ox+26,23)],'#d5e2dc')
  rr(t,(ox+13,17,ox+14,18),'#ddb85b');rr(t,(ox+20,17,ox+21,18),'#ddb85b');rr(t,(ox+12,4,ox+22,5),'#e9d49e')
 if k==7: # boss
  rr(t,(ox+6,11,ox+27,25),'#3b4657');poly(t,[(ox+8,13),(ox+5,4),(ox+14,10)],'#3b4657');poly(t,[(ox+26,13),(ox+30,4),(ox+19,10)],'#3b4657')
  rr(t,(ox+11,16,ox+14,19),'#e0c3ae');rr(t,(ox+21,16,ox+24,19),'#e0c3ae');rr(t,(ox+15,21,ox+20,22),'#a96e73')
im2.save(P/'items.png',optimize=True)
print('sprite assets',[(p.name,p.stat().st_size) for p in P.glob('*.png')])
